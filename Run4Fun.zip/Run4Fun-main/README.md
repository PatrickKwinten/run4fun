# Run4Fun
An application to set up events and compete with other runners
